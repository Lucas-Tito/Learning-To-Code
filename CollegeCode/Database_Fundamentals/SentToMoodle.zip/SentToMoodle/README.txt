coloquei duas versões do dump pois a que dava pra ler em um editor de textos (plain) não
funcionava na hora de importar. E a versão que dava não tinha como abrir em um editor de textos

Não obstante, também adicionei um link para um projeto no github, onde disponibilizei os meus inserts que fiz a mão.